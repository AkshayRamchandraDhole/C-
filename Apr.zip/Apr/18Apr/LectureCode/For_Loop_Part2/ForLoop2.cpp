#include<iostream>
int main(){
	for(int i=1;i<=5;i++){
		
		std::cout<<i<<std::endl;	
	}
	return 0;
}
