#include<stdio.h>
void main(){
	int sum=0;
	int i=1;
	for(;i<=10;){
		//printf("%c\n",i);
		sum=sum+i;
		i++;
	}
		printf("Sum=%d\n",sum);
}
