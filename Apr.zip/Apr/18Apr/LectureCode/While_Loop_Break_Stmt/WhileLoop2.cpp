#include<iostream>
int main(){
	int i=65;
	while(i<=90){
	std::cout<<i<<std::endl;
	i++;
	}
	return 0;
}
