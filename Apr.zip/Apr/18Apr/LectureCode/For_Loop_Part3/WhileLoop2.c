#include<stdio.h>
void main(){
	int i=1;
	while(i<=100){
		if(i%8==0)
			printf("%d\n",i);
	i++;
	}
}
