#include<iostream>
int main(){
		
	for(char ch='A';ch<='Z';ch++){
		std::cout<<ch<<std::endl;
	}
	/*for(int i=65;i<=90;i++);{
		std::cout<<i<<std::endl;
	}*/
	return 0;
}
