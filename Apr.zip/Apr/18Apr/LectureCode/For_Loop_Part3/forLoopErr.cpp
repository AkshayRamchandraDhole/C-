#include<iostream>
int main(){
	//int i=97;
	//for(){	
	//}
	//for(;;){ 
	//}
//	for(;){
//	}
	
	/*for(;i<=122;i++){
		std::cout<<i<<std::endl;
	}*/
	
	int i=97;
	for(;i<=122;);{
		std::cout<<i<<std::endl;
		i++;
	}
	return 0;
}
