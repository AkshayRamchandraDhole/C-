#include<stdio.h>
void main(){
	
	int i=97;
	/*for(;;){
	}
	for(;){
	}
	for(;i<=122;i++){
		printf("%c\n",i);
	}*/
	for(;i<=122;){
		printf("%c\n",i);
		i++;
	}

}
