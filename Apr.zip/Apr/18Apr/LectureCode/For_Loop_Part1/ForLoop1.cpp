#include<iostream>
int main(){

	for(int i=1;i<=10;i++){
		std::cout<<"Core2web"<<std::endl;
	}
	return 0;
}
