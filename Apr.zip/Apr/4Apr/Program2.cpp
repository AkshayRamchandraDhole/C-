#include<iostream>
int main(){
	
	int x=12,y=9;
	
	std::cout<<(x == y)<<std::endl;
	std::cout<<(x <= y)<<std::endl;
	std::cout<<(x >= y)<<std::endl;
	std::cout<<(x != y)<<std::endl;
	std::cout<<(x != y && x > y)<<std::endl;
	std::cout<<(y < x || x > y)<<std::endl;

}
