#include<iostream>
int main(){
	
	int x=3;
	int a = ++x + ++x + ++x + ++x;
	
	std::cout<<"Value of a and x : "<<a<<" "<<x<<" "<<std::endl;
}
