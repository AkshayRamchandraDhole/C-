#include<iostream>
int main(){
	
	int a=3,b=4,c=0;
	int z = a &&b &&a || c ;
	
	std::cout<<"Value of Z : "<<z<<std::endl;
}
