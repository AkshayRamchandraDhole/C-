#include<iostream>
int main(){
	
	int a=12,b=4,c=20,d=5;
	
	int add = a + b;
	int sub = c - b;
	int div = a/ b ;
	int mul = b * d;

	std::cout<<"ADD = "<<add<<std::endl;
	std::cout<<"SUB = "<<sub<<std::endl;
	std::cout<<"DIV = "<<div<<std::endl;
	std::cout<<"MUL = "<<mul<<std::endl;
	

}
