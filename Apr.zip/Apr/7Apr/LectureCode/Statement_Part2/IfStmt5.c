#include<stdio.h>
void main(){

	int marks = 89 ;
	if(marks > 90);{
		printf("Laptop\n");
		printf("Bike\n");
		printf("Watch\n");
	}
	
	printf("New T-Shirt\n");
}
