#include<iostream>
int main(){

	int marks = 93 ;
	if(marks > 90){
		std::cout<<"Laptop"<<std::endl;
		std::cout<<"Bike"<<std::endl;
		std::cout<<"Watch"<<std::endl;
	}
	std::cout<<"New T-Shirt"<<std::endl;
	return 0 ;
}
