#include<stdio.h>
void main(){

	int a = 10 ;
	if(a != 10)
		printf("Equals\n");
		printf("End of If\n");
}
