#include<stdio.h>
void main(){

	int a = 5 ;
	if(a != 10)
		printf("a is greater\n");
}
