#include<iostream>
int main(){

	int a = 10 ;
	if(a != 10)
		std::cout<<"Equals"<<std::endl;
		std::cout<<"End of If"<<std::endl;
	return 0 ;
}
