#include<iostream>
int main(){

	int a = 5 ;
	if(a < 10)
		std::cout<<"a is smaller"<<std::endl;
	return 0 ;
}
