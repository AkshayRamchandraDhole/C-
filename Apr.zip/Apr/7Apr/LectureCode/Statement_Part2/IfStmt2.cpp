#include<iostream>
int main(){

	int a = 5 ;
	int b = 10 ;
	int c = 0 ;
	if(a && b)
		std::cout<<"Core2web"<<std::endl;
	if(b && c)
		std::cout<<"Biencaps"<<std::endl;
	if(b || c)
		std::cout<<"Amazon"<<std::endl;
	return 0 ;
}
