#include<iostream>
int main(){

	std::cout<<"Core2web"<<std::endl
	;;;
	std::cout<<"Biencaps"<<std::endl;
}
