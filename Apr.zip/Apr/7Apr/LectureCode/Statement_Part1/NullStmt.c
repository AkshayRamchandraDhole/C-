#include<stdio.h>
void main(){

	printf("Core2web\n")
	;;;;;
	printf("Biencaps\n");
}
