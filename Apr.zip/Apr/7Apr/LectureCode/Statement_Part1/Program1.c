#include<stdio.h>
#define PI 3.14
void main(){

	int a;
	printf("%d\n",a);
	printf("%f\n",PI);
}
