#include<iostream>
int main(){

	int a = 10 ;
	int b = 20 ;
	int ans = 0 ;
	ans = a + b ; // expression statement
	std::cout<<ans<<std::endl;
	ans = 20 + 45;
	std::cout<<ans<<std::endl;
	return 0;
}
