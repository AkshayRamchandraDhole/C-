#include<stdio.h>
void main(){

	int a = 10 ;
	int b = 20 ;
	int ans = 0 ;
	ans = a + b ; // expression statement
	printf("%d\n",ans);
	ans = 20 + 45;
	printf("%d\n",ans);
}
