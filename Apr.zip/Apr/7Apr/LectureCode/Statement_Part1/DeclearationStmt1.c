#include<stdio.h>
void main(){

	extern int a;
	//int b=20;
	//printf("%d\n",a);
	//printf("%d\n",b);
	printf("%ld\n",sizeof(a));
	//printf("%ld\n",sizeof(b));
}
