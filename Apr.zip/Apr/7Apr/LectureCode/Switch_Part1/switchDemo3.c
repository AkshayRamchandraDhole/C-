#include<stdio.h>
void main(){

	int  a = 1;
	switch(a){
	
		case 1 : 
			printf("Inside Switch\n");
	}
			printf("Outside Switch\n");
}
