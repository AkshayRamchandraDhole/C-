#include<iostream>
int main(){

	int  a = 1;
	//without expression 
	switch(a){
		std::cout<<"Inside Switch"<<std::endl;
	}
		std::cout<<"Outside Switch"<<std::endl;
	return 0 ;
}

