#include<stdio.h>
void main(){

	char a = 65 ;
	switch(a){
	
		case 'A' : {
			printf("A\n");
			printf("1\n");
			}
		break;
	}
			printf("Outside Switch\n");
}
