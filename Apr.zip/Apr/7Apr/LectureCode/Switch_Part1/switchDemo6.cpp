#include<iostream>
int main(){

	int  a = 1;
	char ch = 'S';
	float f = 20.5 ;
	switch(f){
			
		case 20.5 : 
			std::cout<<"S"<<std::endl;
		break;
	}
			std::cout<<"Outside Switch"<<std::endl;
	return 0 ;
}
