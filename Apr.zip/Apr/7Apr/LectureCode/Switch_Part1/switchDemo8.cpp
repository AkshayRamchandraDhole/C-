#include<iostream>
int main(){

	int  a = 65;
	switch(a){
		
			case 'A' : {		
				std::cout<<"A"<<std::endl;
				std::cout<<"1"<<std::endl;
				}
			break;
	}
				std::cout<<"Outside Switch"<<std::endl;
	return 0 ;
}
