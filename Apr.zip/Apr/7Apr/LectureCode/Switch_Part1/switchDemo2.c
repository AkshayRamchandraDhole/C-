#include<stdio.h>
void main(){

	int  a = 1;

	switch(a){
		printf("Inside Switch\n");
	
	}
	printf("Outside Switch\n");
}
