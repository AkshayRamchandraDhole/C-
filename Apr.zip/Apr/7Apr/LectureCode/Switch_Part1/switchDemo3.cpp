#include<iostream>
int main(){

	int  a = 1;
	switch(a){
		
			case 1 : 		
				std::cout<<"Inside Switch"<<std::endl;
	}
				std::cout<<"Outside Switch"<<std::endl;
	return 0 ;
}
