#include<stdio.h>
void main(){

	int  a = 1;
	char ch = 'S';
	float f = 20.5;
	switch(f){
		
		case 20.5 : 
			printf("S\n");
		break;
	}
		printf("Outside Switch\n");
}
