#include<iostream>
int main(){

	int  a = 1;
	//without expression 
	switch(){

	}
	//without case 
	/*switch(a){

	}*/
	return 0 ;
}
