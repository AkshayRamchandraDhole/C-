#include<iostream>
int main(){
	int username = 123 ;
	int password = 456 ;
	if(username == 23 && password == 456)
			std::cout<<"Sucessfully Login"<<std::endl;
	else
			std::cout<<"Invalid Username or Password"<<std::endl;
	return 0;
}
