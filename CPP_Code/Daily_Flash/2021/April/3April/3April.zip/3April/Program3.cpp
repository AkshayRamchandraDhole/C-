#include<iostream>
int main(){

	int a=100,b=200,c;
	c = (a==100 || b > 200);
	std::cout<<"Value of C :"<<c<<std::endl;
	return 0;
}
