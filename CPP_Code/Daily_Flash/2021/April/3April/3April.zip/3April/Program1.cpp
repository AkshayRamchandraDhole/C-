#include<iostream>
int main(){

	int i=3,j;
	j=i++;
	std::cout<<"Value of I and J :"<<i<<" "<<j<<" "<<std::endl;
	return 0;
}
