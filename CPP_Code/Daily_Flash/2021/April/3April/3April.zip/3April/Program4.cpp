#include<iostream>
int main(){

	int x=55;
	std::cout<< x<= 55 << x = 40 << x>=10 <<std::endl;
	return 0;
}
