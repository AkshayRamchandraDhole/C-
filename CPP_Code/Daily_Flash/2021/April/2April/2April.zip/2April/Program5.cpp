#include<iostream>
int main(){

	int i = 10 , j = 10,k;
	k = ++i + j++ ;
	std::cout<<"Value of i,j & k :"<<i<<" "<<j<<" "<<k<<" "<<std::endl;
	return 0;
}
