#include<iostream>
int main(){

	int num = 7 ;
	num = num / 4 ;
	std::cout<<num<<std::endl;
	return 0;
}
