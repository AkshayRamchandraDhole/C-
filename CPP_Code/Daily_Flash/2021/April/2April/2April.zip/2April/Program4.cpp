#include<iostream>
int main(){

	int a = 20 ;
	double b = 15.6 ;
	int c;
	c = a + b ;
	std::cout<<"Value of C :"<<c<<std::endl;
	return 0;
}
