#include<iostream>
int main(){

	int num = 4 * 5 / 2 + 9 ;
	std::cout<<num<<std::endl;
	return 0;
}
