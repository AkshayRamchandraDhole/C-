#include<stdio.h>
void main(){
	int username = 123 ;
	int password = 456 ;
	if(username == 321 && password == 456)
			printf("Successfully Login\n");
	else
			printf("Invalid Username or Password\n");
}
