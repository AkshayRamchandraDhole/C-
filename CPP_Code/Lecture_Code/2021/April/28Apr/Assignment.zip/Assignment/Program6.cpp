#include<iostream>
int main(){

	for(int i=65;i<=90;i++){
		
		std::cout<<char(i)<<"\t";
	}
	
	std::cout<<""<<std::endl;
	
	for(int i=97;i<=122;i++){
		
		std::cout<<char(i)<<"\t";
	}

	std::cout<<""<<std::endl;
	return 0;
}
