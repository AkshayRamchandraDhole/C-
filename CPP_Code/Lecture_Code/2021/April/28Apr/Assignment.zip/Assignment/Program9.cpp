#include<iostream>
int main(){

	for(int i=30;i>=15;i--){
		
		if(i%2==0)
			std::cout<<i<<std::endl;
	}
	return 0;
}
