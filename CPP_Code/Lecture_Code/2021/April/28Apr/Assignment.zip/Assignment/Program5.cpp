#include<iostream>
int main(){

	for(int i=1;i<=128;i++){
		
		std::cout<<char(i)<<"\t";
	}
	std::cout<<""<<std::endl;
	return 0;
}
