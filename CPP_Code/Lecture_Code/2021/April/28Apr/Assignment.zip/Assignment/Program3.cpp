#include<iostream>
int main(){

	for(int i=50;i<=70;i++){
		
		if(i%2==0)
			std::cout<<i<<std::endl;
	}
	return 0;
}
