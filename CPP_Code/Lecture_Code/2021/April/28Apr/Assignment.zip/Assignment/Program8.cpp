#include<iostream>
int main(){

	for(int i=122;i>=97;i--){
		
		std::cout<<char(i)<<std::endl;
	}
	return 0;
}
