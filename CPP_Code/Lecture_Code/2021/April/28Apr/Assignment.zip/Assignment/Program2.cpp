#include<iostream>
int main(){

	for(int i=20;i<=40;i++){
		
		if(i%2!=0)
			std::cout<<i<<std::endl;
	}
	return 0;
}
